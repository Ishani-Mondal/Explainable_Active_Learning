.. lime documentation master file, created by
   sphinx-quickstart on Fri Mar 18 16:20:40 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Local Interpretable Model-Agnostic Explanations (lime)
================================
In this page, you can find the Python API reference for the lime package (local interpretable model-agnostic explanations).
For tutorials and more information, visit `the github page <https://github.com/marcotcr/understanding-ml>`_.


.. toctree::
   :maxdepth: 2

   lime 



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


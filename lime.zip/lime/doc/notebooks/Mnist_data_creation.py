import time
import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_random_state
import sklearn
from sklearn.metrics import roc_auc_score

t0 = time.time()
train_samples = 60000
# Load data from https://www.openml.org/d/554
X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
X = X.reshape((X.shape[0], -1))
X_train, X_test, y_train, y_test = train_test_split(
X, y, train_size=train_samples, test_size=10000)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

print("==================")
X_train=list(X_train)
X_test=list(X_test)
print(len(X_train))
print(len(X_test))
print("==================")

templist = []
for tup in zip(X_train, y_train):
    if(tup[1]=='8' or tup[1]=='3'):
        templist.append(list(tup))
    
testList = []
for tup in zip(X_test, y_test):
    if(tup[1]=='8' or tup[1]=='3'):
        testList.append(list(tup))
    
print("Initial Training set size = "+str(len(templist)))
print("Initial Test set size = "+str(len(testList)))

X_test=[]
y_test=[]

for tup in testList:
	X_test.append(tup[0])
	y_test.append(tup[1])

import random
random.shuffle(templist)

seed_size=int(0.1*len(templist))

seed_list=templist[0:seed_size]
print("Initial Seed set size = "+str(len(seed_list)))

unlabelled_list=templist[seed_size:]
print("Unlabelled dataset size = "+str(len(unlabelled_list)))


def random_instance_generate(seed_set, unlabelled_list, batch_size):
	random_elements=[]
	print("Before Sampling Unlabelled Data Size: "+str(len(unlabelled_list)))
	random.shuffle(unlabelled_list)
	for i in range(batch_size):
		rand_elem = random.choice(unlabelled_list)
		random_elements.append(rand_elem)
	for elem in random_elements:
		seed_set.append(elem)
	ul=[]
	for i in random_elements:
		ul.append(list(i[0]))
	new_unlabelled=[]
	for elem in unlabelled_list:
		if(list(elem[0]) in ul):
			continue
		new_unlabelled.append(elem)
	print("After Sampling Unlabelled Data Size : "+str(len(new_unlabelled)))
	return new_unlabelled, seed_set


#def uncertainity_based_instance_generate(seed_set, unlabelled_list, batch_size):


def train_model(data, X_test, y_test):
	print("--------------------Start------------------")
	clf = LogisticRegression(C=50. / train_samples, penalty='l1', solver='saga', tol=0.1)
	print("Training with seed size: "+str(len(data)))
	X_train=[]
	y_train=[]
	for i in range(len(data)):
		X_train.append(list(data[i][0]))
		y_train.append(data[i][1])
	clf.fit(X_train, y_train)
	proba=clf.predict_proba(np.array(X_test))
	print(1 - proba.max(axis=1))
	print("Accuracy on the Test Set is : "+str(sklearn.metrics.accuracy_score(y_test, clf.predict(X_test))))
	print("--------------------End------------------")


stopping_criteria = 10
batch_size = 10

for i in range(stopping_criteria):
	print("Seed Set Size in Iteration " + str(i) +" is :" + str(len(seed_list)))
	train_model(seed_list, X_test, y_test)
	unlabelled_list, seed_list = random_instance_generate(seed_list, unlabelled_list, batch_size)
	

#!/usr/bin/env python
# coding: utf-8

# In[147]:


import time
import matplotlib.pyplot as plt
import numpy as np

from sklearn.datasets import fetch_openml
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_random_state

# Turn down for faster convergence
t0 = time.time()
train_samples = 60000

# Load data from https://www.openml.org/d/554
X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
print(X.shape)

X = X.reshape((X.shape[0], -1))


X_train, X_test, y_train, y_test = train_test_split(
    X, y, train_size=train_samples, test_size=10000)



scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
print(X_train.shape)


# In[149]:


print(X_test.shape)


# In[150]:


feature_names=[]

for i in range(784):
    feature='feature_'+str(i)
    feature_names.append(feature)
    
feature_names[783]

class_names=[]

for i in range(10):
    class_1='class_'+str(i+1)
    class_names.append(class_1)


# X_train[0]

# In[151]:


clf = LogisticRegression(C=50. / train_samples, penalty='l1', solver='saga', tol=0.1)
clf.fit(X_train, y_train)


# In[152]:


#Accuracy on MNIST TestSet after training on the entire data
import sklearn
sklearn.metrics.accuracy_score(y_test, clf.predict(X_test))


# # Preparation of Seed Data (S)

# In[163]:


templist = []
for tup in zip(X_train, y_train):
    if(tup[1]=='8' or tup[1]=='3'):
        templist.append(tup)
        
print(len(templist))


# In[167]:


templist = []
for tup in zip(X_train, y_train):
    if(tup[1]=='8' or tup[1]=='3'):
        templist.append(tup)
    
testList = []
for tup in zip(X_test, y_test):
    if(tup[1]=='8' or tup[1]=='3'):
        testList.append(tup)
    
print("Initial Training set size = "+str(len(templist)))
print("Initial Test set size = "+str(len(testList)))

import random
random.seed(0)
random.shuffle(templist)

seed_size=int(0.1*len(templist))

seed_list=templist[0:seed_size]
print("Initial Seed set size = "+str(len(seed_list)))
#print(seed_list[0])


# # Creating Unlabelled Set (U = X - S)

# In[168]:


unlabelled_list=templist[seed_size:]
print(len(unlabelled_list))


# # Creating Explaination vector for seed_set instance

# In[100]:


import numpy as np
import lime
import lime.lime_tabular
explainer = lime.lime_tabular.LimeTabularExplainer(X_train, feature_names=feature_names, class_names=class_names, discretize_continuous=False)


# In[122]:


total_np_array=[]

for item in seed_list:
    exp = explainer.explain_instance(item[0], clf.predict_proba, num_features=5)
    vectors = np.empty([1, 5])
    for elem in list(exp.as_list()):
        np.append(vectors, elem[1], axis=None)
    total_np_array.append(vectors[0])


# In[130]:


print(total_np_array)


# In[131]:


seed_mean = np.mean(np.array(total_np_array), axis=0)


# In[132]:


seed_mean


# In[146]:


len_unlabelled = len(unlabelled_list)
for i in range(len_unlabelled):
    exp = explainer.explain_instance(unlabelled_list[i][0], clf.predict_proba, num_features=5)
    print(exp.as_list())


# In[34]:


explainer


# In[35]:


exp = explainer.explain_instance(X_train[5], clf.predict_proba, num_features=784)


# In[36]:


exp.as_list()[0]







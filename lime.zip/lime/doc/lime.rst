lime package
============

Subpackages
-----------

.. toctree::

    lime.tests

Submodules
----------

lime\.discretize module
-----------------------

.. automodule:: lime.discretize
    :members:
    :undoc-members:
    :show-inheritance:

lime\.exceptions module
-----------------------

.. automodule:: lime.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

lime\.explanation module
------------------------

.. automodule:: lime.explanation
    :members:
    :undoc-members:
    :show-inheritance:

lime\.lime\_base module
-----------------------

.. automodule:: lime.lime_base
    :members:
    :undoc-members:
    :show-inheritance:

lime\.lime\_image module
------------------------

.. automodule:: lime.lime_image
    :members:
    :undoc-members:
    :show-inheritance:

lime\.lime\_tabular module
--------------------------

.. automodule:: lime.lime_tabular
    :members:
    :undoc-members:
    :show-inheritance:

lime\.lime\_text module
-----------------------

.. automodule:: lime.lime_text
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: lime
    :members:
    :undoc-members:
    :show-inheritance:
